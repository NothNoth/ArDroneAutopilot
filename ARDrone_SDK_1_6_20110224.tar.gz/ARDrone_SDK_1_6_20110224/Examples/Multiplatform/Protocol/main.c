
#include "app.h" 

int main( int argc, char* argv[] )
{
	appInit();
	while(1) sleep(1);

	return 0;
}

