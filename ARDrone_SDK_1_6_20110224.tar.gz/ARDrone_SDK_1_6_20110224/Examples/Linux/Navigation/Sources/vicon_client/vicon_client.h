#ifndef _VICON_CLIENT_H_
#define _VICON_CLIENT_H_

#include <vicon.h>
#include <vicon_file.h>

#endif //! _VICON_CLIENT_H_

